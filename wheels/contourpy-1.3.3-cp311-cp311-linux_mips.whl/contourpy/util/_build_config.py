# _build_config.py.in is converted into _build_config.py during the meson build process.

from __future__ import annotations


def build_config() -> dict[str, str]:
    """
    Return a dictionary containing build configuration settings.

    All dictionary keys and values are strings, for example ``False`` is
    returned as ``"False"``.

        .. versionadded:: 1.1.0
    """
    return dict(
        # Python settings
        python_version="3.11",
        python_install_dir=r"/usr/local/lib/python3/dist-packages/",
        python_path=r"/shaketune-venv/bin/python",

        # Package versions
        contourpy_version="1.3.3",
        meson_version="1.9.1",
        mesonpy_version="0.18.0",
        pybind11_version="3.0.1",

        # Misc meson settings
        meson_backend="ninja",
        build_dir=r"/tmp/pip-wheel-hup72ewp/contourpy_3891ecec39e64d8ab9ec208b384620b4/.mesonpy-5luey8ww/lib/contourpy/util",
        source_dir=r"/tmp/pip-wheel-hup72ewp/contourpy_3891ecec39e64d8ab9ec208b384620b4/lib/contourpy/util",
        cross_build="False",

        # Build options
        build_options=r"-Dbuildtype=release -Db_ndebug=if-release -Db_vscrt=md -Dvsenv=True --native-file=/tmp/pip-wheel-hup72ewp/contourpy_3891ecec39e64d8ab9ec208b384620b4/.mesonpy-5luey8ww/meson-python-native-file.ini",
        buildtype="release",
        cpp_std="c++17",
        debug="False",
        optimization="3",
        vsenv="True",
        b_ndebug="if-release",
        b_vscrt="from_buildtype",

        # C++ compiler
        compiler_name="gcc",
        compiler_version="12.2.0",
        linker_id="ld.bfd",
        compile_command="c++",

        # Host machine
        host_cpu="mips",
        host_cpu_family="mips",
        host_cpu_endian="little",
        host_cpu_system="linux",

        # Build machine, same as host machine if not a cross_build
        build_cpu="mips",
        build_cpu_family="mips",
        build_cpu_endian="little",
        build_cpu_system="linux",
    )
