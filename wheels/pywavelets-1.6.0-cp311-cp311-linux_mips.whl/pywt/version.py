# THIS FILE IS GENERATED DURING THE PYWAVELETS BUILD
# See util/version_utils.py for details

short_version = '1.6.0'
version = '1.6.0'
full_version = '1.6.0'
git_revision = 'Unknown'
release = True

if not release:
    version = full_version
