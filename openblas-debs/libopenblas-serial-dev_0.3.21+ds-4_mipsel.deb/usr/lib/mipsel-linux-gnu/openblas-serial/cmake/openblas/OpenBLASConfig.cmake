SET(OpenBLAS_VERSION "0.3.21")
SET(OpenBLAS_INCLUDE_DIRS /usr/include/mipsel-linux-gnu/openblas-serial/)
SET(OpenBLAS_LIBRARIES /usr/lib/mipsel-linux-gnu/openblas-serial//libopenblas.so)
